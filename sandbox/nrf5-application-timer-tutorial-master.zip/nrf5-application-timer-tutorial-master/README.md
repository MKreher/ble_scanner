# nrf5-application-timer-tutorial

This example is intended to be used together with the [nRF5 SDK Application Timer Tutorial](https://devzone.nordicsemi.com/tutorials/b/software-development-kit/posts/application-timer-tutorial).
